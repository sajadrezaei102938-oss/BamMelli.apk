-- بام ملی: نسخه آموزشی با موجودی و تراکنش‌های غیرواقعی. اجرای این اسکریپت پول واقعی ایجاد نمی‌کند.
create table if not exists public.demo_accounts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 owner text not null check (char_length(owner) between 1 and 80), balance bigint not null default 0 check(balance>=0 and balance<=9000000000000000), created_at timestamptz not null default now(), unique(user_id,owner)
);
create table if not exists public.demo_transactions (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 account_id uuid references public.demo_accounts(id) on delete set null, kind text not null check(kind in ('DEPOSIT','WITHDRAW','TRANSFER','NEW','DEMO')),
 amount bigint not null default 0 check(amount>=0 and amount<=9000000000000000), description text not null default '', owner text not null default '', created_at timestamptz not null default now()
);
alter table public.demo_accounts enable row level security;
alter table public.demo_transactions enable row level security;
drop policy if exists "users read own demo accounts" on public.demo_accounts;
create policy "users read own demo accounts" on public.demo_accounts for select to authenticated using(auth.uid()=user_id);
drop policy if exists "users read own demo transactions" on public.demo_transactions;
create policy "users read own demo transactions" on public.demo_transactions for select to authenticated using(auth.uid()=user_id);
grant select on public.demo_accounts, public.demo_transactions to authenticated;
create or replace function public.initialize_demo_accounts() returns jsonb language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); n int;
begin if uid is null then raise exception 'ورود لازم است'; end if;
 if exists(select 1 from public.demo_accounts where user_id=uid) then return jsonb_build_object('ok',true,'existing',true); end if;
 insert into public.demo_accounts(user_id,owner,balance) values(uid,'علی',15000000),(uid,'سارا',3200000),(uid,'رضا',48500000),(uid,'مریم',7800000);
 insert into public.demo_transactions(user_id,kind,amount,description,owner) values(uid,'DEMO',0,'شروع حساب‌های نمایشی','سیستم');
 return jsonb_build_object('ok',true,'existing',false); end; $$;
revoke all on function public.initialize_demo_accounts() from public; grant execute on function public.initialize_demo_accounts() to authenticated;
create or replace function public.create_demo_account(p_owner text) returns jsonb language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); nm text:=btrim(coalesce(p_owner,'')); aid uuid;
begin if uid is null then raise exception 'ورود لازم است'; end if; if char_length(nm)<1 or char_length(nm)>80 then raise exception 'نام حساب نامعتبر است'; end if;
 insert into public.demo_accounts(user_id,owner,balance) values(uid,nm,0) returning id into aid;
 insert into public.demo_transactions(user_id,account_id,kind,amount,description,owner) values(uid,aid,'NEW',0,'حساب نمایشی ساخته شد',nm);
 return jsonb_build_object('ok',true); end; $$;
revoke all on function public.create_demo_account(text) from public; grant execute on function public.create_demo_account(text) to authenticated;
create or replace function public.apply_demo_operation(p_kind text,p_owner text,p_target text,p_amount bigint,p_description text default '') returns jsonb language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); src public.demo_accounts%rowtype; dst public.demo_accounts%rowtype; amt bigint:=coalesce(p_amount,0); descr text:=left(coalesce(p_description,''),100);
begin if uid is null then raise exception 'ورود لازم است'; end if;
 if p_kind not in ('DEPOSIT','WITHDRAW','TRANSFER') then raise exception 'نوع عملیات نامعتبر است'; end if;
 if amt<=0 or amt>9000000000000000 then raise exception 'مبلغ نامعتبر است'; end if;
 select * into src from public.demo_accounts where user_id=uid and owner=btrim(p_owner) for update; if not found then raise exception 'حساب مبدأ پیدا نشد'; end if;
 if p_kind='DEPOSIT' then if src.balance+amt>9000000000000000 then raise exception 'موجودی خارج از محدوده است'; end if; update public.demo_accounts set balance=balance+amt where id=src.id;
 elsif p_kind='WITHDRAW' then if src.balance<amt then raise exception 'موجودی نمایشی کافی نیست'; end if; update public.demo_accounts set balance=balance-amt where id=src.id;
 else select * into dst from public.demo_accounts where user_id=uid and owner=btrim(p_target) for update; if not found then raise exception 'حساب مقصد پیدا نشد'; end if; if src.id=dst.id then raise exception 'مبدأ و مقصد یکسان‌اند'; end if; if src.balance<amt then raise exception 'موجودی نمایشی کافی نیست'; end if; if dst.balance+amt>9000000000000000 then raise exception 'موجودی مقصد خارج از محدوده است'; end if; update public.demo_accounts set balance=balance-amt where id=src.id; update public.demo_accounts set balance=balance+amt where id=dst.id; end if;
 insert into public.demo_transactions(user_id,account_id,kind,amount,description,owner) values(uid,src.id,p_kind,amt,case when descr='' then p_kind else descr end,case when p_kind='TRANSFER' then btrim(p_owner)||' ← '||btrim(p_target) else btrim(p_owner) end);
 return jsonb_build_object('ok',true); end; $$;
revoke all on function public.apply_demo_operation(text,text,text,bigint,text) from public; grant execute on function public.apply_demo_operation(text,text,text,bigint,text) to authenticated;
